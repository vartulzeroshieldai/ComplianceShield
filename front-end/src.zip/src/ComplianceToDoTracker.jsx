// ComplianceToDoTracker.jsx
import React, { useState, useEffect } from "react";
import {
  FaUserCheck,
  FaShieldAlt,
  FaCertificate,
  FaClipboardCheck,
  FaKey,
  FaUsers,
  FaExclamationTriangle,
  FaCheckCircle,
  FaClock,
  FaChevronDown,
  FaEye,
  FaEdit,
  FaTrash,
  FaBell,
  FaCalendarAlt,
  FaFilter,
  FaSearch,
  FaDownload,
} from "react-icons/fa";

const ComplianceToDoTracker = () => {
  const [filter, setFilter] = useState("all");
  const [searchTerm, setSearchTerm] = useState("");
  const [activeFilterIndex, setActiveFilterIndex] = useState(0);

  const [fieldChoices, setFieldChoices] = useState({
    priority: [],
    status: [],
    category: [],
  });

  useEffect(() => {
    const fetchTodos = async () => {
      try {
        // Fetch todos from the new API endpoint
        const response = await fetch("/api/auditing/todos/", {
          headers: {
            Authorization: `Bearer ${
              localStorage.getItem("authTokens")
                ? JSON.parse(localStorage.getItem("authTokens")).access
                : ""
            }`,
          },
        });

        if (response.ok) {
          const todosData = await response.json();
          setTodoItems(todosData);
        }
      } catch (error) {
        console.error("Failed to fetch todos:", error);
      }
    };

    fetchTodos();
  }, []);

  // Sample data for to-do items
  const [todoItems, setTodoItems] = useState([
    {
      id: 1,
      title: "Access Control Review",
      type: "User Management",
      description:
        "Review and approve user access permissions for new employees",
      priority: "High",
      status: "Pending",
      assignee: "John Smith",
      dueDate: "Dec 25, 2025",
      category: "user_approval",
      requester: "HR Department",
      details: {
        usersCount: 5,
        department: "Engineering",
      },
      actions: ["Approve", "Reject"],
    },
    {
      id: 2,
      title: "Data Breach Risk Assessment",
      type: "Risk Management",
      description:
        "Approve risk assessment documentation for data breach scenario",
      priority: "Medium",
      status: "Approved",
      assignee: "Sarah Johnson",
      dueDate: "Dec 22, 2025",
      category: "risk_approval",
      requester: "Security Team",
      details: {
        riskLevel: "High",
        impactScore: 8.5,
      },
      actions: ["Approve", "Reject"],
    },
    {
      id: 3,
      title: "ISO 27001 Subcontrols Validation",
      type: "Controls",
      description: "Enable auditor assignment for compliance validation",
      priority: "High",
      status: "Pending",
      assignee: "Mike Davis",
      dueDate: "Dec 28, 2025",
      category: "auditor_assignment",
      requester: "Compliance Office",
      details: {
        controlsCount: 12,
        framework: "ISO 27001",
      },
      actions: ["Assign Auditor", "View Details"],
    },
    {
      id: 4,
      title: "Evidence Validation",
      type: "Auditor Review",
      description: "Review and approve uploaded compliance evidence documents",
      priority: "Medium",
      status: "Approved",
      assignee: "Jane Smith",
      dueDate: "Dec 20, 2025",
      category: "evidence_approval",
      requester: "Legal Team",
      details: {
        documentsCount: 8,
        totalSize: "2.4 MB",
      },
      actions: ["Approve", "Reject"],
    },
    {
      id: 5,
      title: "Password Policy Compliance",
      type: "User Management",
      description:
        "Approve new password policy implementation across organization",
      priority: "High",
      status: "Pending",
      assignee: "Tom Wilson",
      dueDate: "Dec 30, 2025",
      category: "policy_approval",
      requester: "IT Security",
      details: {
        usersAffected: 150,
        policyVersion: "v2.1",
      },
      actions: ["Approve", "Reject"],
    },
    {
      id: 6,
      title: "Network Security Assessment",
      type: "Risk Management",
      description:
        "Review network vulnerability assessment and approve remediation plan",
      priority: "High",
      status: "Pending",
      assignee: "Lisa Brown",
      dueDate: "Dec 26, 2025",
      category: "risk_approval",
      requester: "Network Team",
      details: {
        vulnerabilities: 3,
        severity: "High",
      },
      actions: ["Approve", "Reject"],
    },
    {
      id: 7,
      title: "User Role/Organization Assignment Approval",
      type: "User Management",
      description:
        "Approve role assignment (Contributor) and organization (datasc) for user John Doe",
      priority: "High",
      status: "Pending",
      assignee: "Admin",
      dueDate: new Date(
        Date.now() + 7 * 24 * 60 * 60 * 1000
      ).toLocaleDateString(),
      category: "user_approval",
      requester: "System",
      details: {
        userId: 123,
        userName: "John Doe",
        userEmail: "john.doe@example.com",
        newRole: "Contributor",
        newOrganization: "datasc",
        department: "User Management",
      },
      actions: ["Approve", "Reject"],
    },
    {
      id: 8,
      title: "Auditor Assignment Approval",
      type: "Project Management",
      description:
        'Approve auditor assignment for project "ISO 27001 Compliance Project". Auditor: Tarun Kumar - datasc',
      priority: "High",
      status: "Pending",
      assignee: "Admin",
      dueDate: new Date(
        Date.now() + 7 * 24 * 60 * 60 * 1000
      ).toLocaleDateString(),
      category: "auditor_assignment",
      requester: "Project Owner",
      details: {
        auditorId: 456,
        auditorName: "Tarun Kumar",
        auditorEmail: "tarun.kumar@datasc.com",
        auditorOrganization: "datasc",
        projectId: 5,
        projectName: "ISO 27001 Compliance Project",
        projectFramework: "ISO 27001",
        department: "Project Management",
      },
      actions: ["Approve", "Reject"],
    },
    {
      id: 9,
      title: "Risk Assessment Approval",
      type: "Risk Management",
      description:
        'Approve risk assessment for "Data Breach Risk". Category: Security, Rating: High, Impact: Severe',
      priority: "High",
      status: "Pending",
      assignee: "Admin",
      dueDate: new Date(
        Date.now() + 7 * 24 * 60 * 60 * 1000
      ).toLocaleDateString(),
      category: "risk_approval",
      requester: "Risk Manager",
      details: {
        riskId: 123,
        riskTitle: "Data Breach Risk",
        riskDescription:
          "Potential unauthorized access to sensitive customer data",
        riskCategory: "Security",
        riskRating: "High",
        impact: "Severe",
        likelihood: "Possible",
        projectId: 5,
        projectName: "ISO 27001 Compliance Project",
        targetMitigationDate: "2025-03-15",
        mitigationStrategy:
          "Implement multi-factor authentication and data encryption",
        department: "Risk Management",
      },
      actions: ["Approve", "Reject"],
    },
    {
      id: 10,
      title: "User Access Request Rejected",
      type: "User Management",
      description:
        "User access request for John Smith has been rejected due to insufficient documentation",
      priority: "Medium",
      status: "Rejected",
      assignee: "Admin",
      dueDate: new Date(
        Date.now() - 2 * 24 * 60 * 60 * 1000
      ).toLocaleDateString(),
      category: "user_approval",
      requester: "HR Department",
      details: {
        userId: 789,
        userName: "John Smith",
        userEmail: "john.smith@example.com",
        newRole: "Contributor",
        newOrganization: "datasc",
        department: "User Management",
        rejectionReason: "Insufficient documentation provided",
      },
      actions: ["Approve", "Reject"],
    },
  ]);

  // Available auditors for assignment
  const auditors = [
    { id: 1, name: "Dr. Emily Carter", specialization: "ISO 27001" },
    { id: 2, name: "Michael Thompson", specialization: "SOC 2" },
    { id: 3, name: "Sarah Williams", specialization: "GDPR" },
    { id: 4, name: "David Chen", specialization: "NIST" },
  ];

  // Status configurations
  const statusConfig = {
    Pending: {
      bgColor: "bg-yellow-100",
      textColor: "text-yellow-800",
      icon: FaClock,
      iconColor: "text-yellow-500",
    },
    Approved: {
      bgColor: "bg-green-100",
      textColor: "text-green-800",
      icon: FaCheckCircle,
      iconColor: "text-green-500",
    },
    Rejected: {
      bgColor: "bg-red-100",
      textColor: "text-red-800",
      icon: FaExclamationTriangle,
      iconColor: "text-red-500",
    },
  };

  // Priority configurations
  const priorityConfig = {
    High: {
      bgColor: "bg-red-50",
      textColor: "text-red-700",
      borderColor: "border-red-200",
    },
    Medium: {
      bgColor: "bg-yellow-50",
      textColor: "text-yellow-700",
      borderColor: "border-yellow-200",
    },
    Low: {
      bgColor: "bg-green-50",
      textColor: "text-green-700",
      borderColor: "border-green-200",
    },
  };

  // Category icons
  const categoryIcons = {
    user_approval: FaUserCheck,
    risk_approval: FaShieldAlt,
    auditor_assignment: FaCertificate,
    evidence_approval: FaClipboardCheck,
    policy_approval: FaKey,
  };

  // Filter options
  const filters = [
    { id: "all", label: "All Tasks", count: todoItems.length },
    {
      id: "pending",
      label: "Pending",
      count: todoItems.filter((item) => item.status === "Pending").length,
    },
    {
      id: "approved",
      label: "Approved",
      count: todoItems.filter((item) => item.status === "Approved").length,
    },
    {
      id: "rejected",
      label: "Rejected",
      count: todoItems.filter((item) => item.status === "Rejected").length,
    },
  ];

  // Progress data
  const progressData = {
    approved: todoItems.filter((item) => item.status === "Approved").length,
    pending: todoItems.filter((item) => item.status === "Pending").length,
    rejected: todoItems.filter((item) => item.status === "Rejected").length,
    total: todoItems.length,
  };

  const approvedPercentage = Math.round(
    (progressData.approved / progressData.total) * 100
  );
  const pendingPercentage = Math.round(
    (progressData.pending / progressData.total) * 100
  );
  const rejectedPercentage = Math.round(
    (progressData.rejected / progressData.total) * 100
  );

  // Handle filter change with index tracking
  const handleFilterChange = (filterId) => {
    setFilter(filterId);
    const index = filters.findIndex(f => f.id === filterId);
    setActiveFilterIndex(index);
  };

  // Filter items based on current filter and search
  const filteredItems = todoItems.filter((item) => {
    const matchesFilter =
      filter === "all" || item.status.toLowerCase() === filter;
    const matchesSearch =
      item.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.type.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (item.assignee &&
        item.assignee.toLowerCase().includes(searchTerm.toLowerCase()));
    return matchesFilter && matchesSearch;
  });

  const handleAction = async (itemId, action) => {
    console.log(`Action: ${action} on item ${itemId}`);

    // Find the task item
    const task = todoItems.find((item) => item.id === itemId);

    if (task && task.category === "user_approval") {
      // Handle user approval/rejection
      await handleUserApproval(itemId, action, task);
    } else if (task && task.category === "auditor_assignment") {
      // Handle auditor assignment approval/rejection
      await handleAuditorApproval(itemId, action, task);
    } else if (task && task.category === "risk_approval") {
      // Handle risk approval/rejection
      await handleRiskApproval(itemId, action, task);
    } else {
      // Handle other task actions
      console.log(`Handling ${action} for task ${itemId}`);
    }
  };

  // Handle user approval/rejection
  const handleUserApproval = async (itemId, action, task) => {
    try {
      const userId = task.details.userId;
      const newStatus = action === "Approve" ? "active" : "pending_approval";

      // Update todo status via API
      const response = await fetch(`/api/auditing/todos/${itemId}/`, {
        method: "PATCH",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${
            localStorage.getItem("authTokens")
              ? JSON.parse(localStorage.getItem("authTokens")).access
              : ""
          }`,
        },
        body: JSON.stringify({
          status: action === "Approve" ? "Approved" : "Rejected",
        }),
      });

      if (response.ok) {
        // Update the task status in state
        setTodoItems((prevItems) =>
          prevItems.map((item) =>
            item.id === itemId
              ? {
                  ...item,
                  status: action === "Approve" ? "Approved" : "Rejected",
                }
              : item
          )
        );

        console.log(`User ${userId} ${action.toLowerCase()}d successfully`);

        // Show success message
        alert(
          `User ${action.toLowerCase()}d successfully! Status updated to ${newStatus}.`
        );
      } else {
        throw new Error("Failed to update user status");
      }
    } catch (error) {
      console.error("Error handling user approval:", error);
      alert(`Error ${action.toLowerCase()}ing user: ${error.message}`);
    }
  };

  // Handle auditor assignment approval/rejection
  const handleAuditorApproval = async (itemId, action, task) => {
    try {
      const auditorId = task.details.auditorId;
      const projectId = task.details.projectId;

      // Update todo status via API
      const response = await fetch(`/api/auditing/todos/${itemId}/`, {
        method: "PATCH",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${
            localStorage.getItem("authTokens")
              ? JSON.parse(localStorage.getItem("authTokens")).access
              : ""
          }`,
        },
        body: JSON.stringify({
          status: action === "Approve" ? "Approved" : "Rejected",
        }),
      });

      if (response.ok) {
        // If rejected, remove the auditor from the project
        if (action === "Reject") {
          try {
            const removeResponse = await fetch(
              `/api/projects/${projectId}/remove_auditor/`,
              {
                method: "DELETE",
                headers: {
                  "Content-Type": "application/json",
                  Authorization: `Bearer ${
                    localStorage.getItem("authTokens")
                      ? JSON.parse(localStorage.getItem("authTokens")).access
                      : ""
                  }`,
                },
                body: JSON.stringify({
                  auditor_id: auditorId,
                }),
              }
            );

            if (removeResponse.ok) {
              console.log("Auditor removed from project after rejection");
            } else {
              console.warn(
                "Failed to remove auditor from project after rejection"
              );
            }
          } catch (removeError) {
            console.error("Error removing auditor from project:", removeError);
          }
        }

        // Update the task status in state
        setTodoItems((prevItems) =>
          prevItems.map((item) =>
            item.id === itemId
              ? {
                  ...item,
                  status: action === "Approve" ? "Approved" : "Rejected",
                }
              : item
          )
        );

        console.log(`Auditor assignment ${action.toLowerCase()}d successfully`);

        // Show success message
        alert(
          `Auditor assignment ${action.toLowerCase()}d successfully! ${
            action === "Approve"
              ? "Auditor has been approved for the project."
              : "Auditor assignment has been rejected and auditor removed from project."
          }`
        );
      } else {
        throw new Error("Failed to update auditor assignment status");
      }
    } catch (error) {
      console.error("Error handling auditor approval:", error);
      alert(
        `Error ${action.toLowerCase()}ing auditor assignment: ${error.message}`
      );
    }
  };

  // Handle risk approval/rejection
  const handleRiskApproval = async (itemId, action, task) => {
    try {
      const riskId = task.details.riskId;

      // Update todo status via API
      const response = await fetch(`/api/auditing/todos/${itemId}/`, {
        method: "PATCH",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${
            localStorage.getItem("authTokens")
              ? JSON.parse(localStorage.getItem("authTokens")).access
              : ""
          }`,
        },
        body: JSON.stringify({
          status: action === "Approve" ? "Approved" : "Rejected",
        }),
      });

      if (response.ok) {
        // If rejected, we could potentially update the risk status or delete it
        // For now, we'll just update the task status
        if (action === "Reject") {
          try {
            // Optionally update risk status to rejected
            const riskResponse = await fetch(`/api/auditing/risks/${riskId}/`, {
              method: "PATCH",
              headers: {
                "Content-Type": "application/json",
                Authorization: `Bearer ${
                  localStorage.getItem("authTokens")
                    ? JSON.parse(localStorage.getItem("authTokens")).access
                    : ""
                }`,
              },
              body: JSON.stringify({
                status: "rejected",
              }),
            });

            if (riskResponse.ok) {
              console.log("Risk status updated to rejected");
            } else {
              console.warn("Failed to update risk status after rejection");
            }
          } catch (riskError) {
            console.error("Error updating risk status:", riskError);
          }
        }

        // Update the task status in state
        setTodoItems((prevItems) =>
          prevItems.map((item) =>
            item.id === itemId
              ? {
                  ...item,
                  status: action === "Approve" ? "Approved" : "Rejected",
                }
              : item
          )
        );

        console.log(`Risk assessment ${action.toLowerCase()}d successfully`);

        // Show success message
        alert(
          `Risk assessment ${action.toLowerCase()}d successfully! ${
            action === "Approve"
              ? "Risk has been approved and is now active."
              : "Risk assessment has been rejected."
          }`
        );
      } else {
        throw new Error("Failed to update risk approval status");
      }
    } catch (error) {
      console.error("Error handling risk approval:", error);
      alert(
        `Error ${action.toLowerCase()}ing risk assessment: ${error.message}`
      );
    }
  };

  const handleAuditorAssign = (itemId, auditorId) => {
    console.log(`Assigning auditor ${auditorId} to item ${itemId}`);
    // Implement auditor assignment logic here
  };

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-gray-900 mb-2">
                Compliance To-Do Tracker
              </h1>
              <p className="text-gray-600">
                Review, validate, and approve compliance actions across all
                controls, users, risks, controls, evidence, and auditors.
              </p>
            </div>
            <div className="flex items-center space-x-4">
              <button className="flex items-center space-x-2 px-6 py-3 bg-white text-teal-500 rounded-full shadow hover:bg-teal-500 hover:text-white font-semibold transition-all duration-200 transform hover:scale-105 active:scale-95 cursor-pointer">
                <FaDownload className="w-4 h-4" />
                <span>Export Report</span>
              </button>
              <button className="flex items-center space-x-2 px-6 py-3 bg-white text-gray-500 rounded-full shadow hover:bg-gray-500 hover:text-white font-semibold transition-all duration-200 transform hover:scale-105 active:scale-95 cursor-pointer">
                <FaBell className="w-4 h-4" />
                <span>Notifications</span>
              </button>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-12 gap-8">
          {/* Main Content */}
          <div className="col-span-8 space-y-6">
            {/* Filters and Search */}
            <div className="bg-white rounded-xl border border-gray-200 shadow-lg p-6">
              <div className="flex items-center gap-4 mb-4">
                <div className="relative flex-1" style={{ width: '80%' }}>
                  <FaSearch className="absolute left-3 top-3 w-4 h-4 text-gray-400" />
                  <input
                    type="text"
                    placeholder="Search tasks..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-500 focus:border-teal-500 transition-all duration-200 shadow-sm hover:shadow-md"
                  />
                </div>
                <button className="flex items-center space-x-2 px-4 py-3 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-all duration-200 shadow-sm hover:shadow-md">
                    <FaFilter className="w-4 h-4" />
                    <span>Filter</span>
                  </button>
              </div>

              {/* Filter Tabs */}
              <div className="bg-white rounded-lg border border-gray-200 shadow-sm overflow-hidden">
                <div className="relative p-1">
                  <div
                    className="absolute top-1 left-1 bg-teal-100 rounded-lg transition-all duration-500 ease-out shadow-sm"
                    style={{
                      width: `${100 / filters.length}%`,
                      height: "calc(100% - 8px)",
                      transform: `translateX(${activeFilterIndex * 100}%)`,
                    }}
                  />
                  <div className="relative flex">
                    {filters.map((filterOption) => (
                      <button
                        key={filterOption.id}
                        onClick={() => handleFilterChange(filterOption.id)}
                        className={`flex-1 px-4 py-2 text-sm font-medium rounded-lg transition-all duration-500 ease-out relative z-10 ${
                          filter === filterOption.id
                            ? "text-teal-700"
                            : "text-gray-600 hover:text-gray-800"
                        }`}
                      >
                        {filterOption.label} ({filterOption.count})
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            {/* Todo Items */}
            <div className="space-y-4">
              {filteredItems.map((item) => {
                const statusConf = statusConfig[item.status];
                const priorityConf = priorityConfig[item.priority];
                const CategoryIcon = categoryIcons[item.category];
                const StatusIcon = statusConf.icon;

                return (
                  <div
                    key={item.id}
                    className={`bg-white rounded-xl border-l-4 ${priorityConf.borderColor} shadow-lg hover:shadow-xl transition-all duration-300 hover:-translate-y-1 border border-gray-200`}
                  >
                    <div className="p-6">
                      {/* Header */}
                      <div className="flex items-start justify-between mb-4">
                        <div className="flex items-start space-x-4">
                          <div
                            className={`p-3 ${priorityConf.bgColor} rounded-lg`}
                          >
                            <CategoryIcon
                              className={`w-6 h-6 ${priorityConf.textColor}`}
                            />
                          </div>
                          <div className="flex-1">
                            <div className="flex items-center space-x-3 mb-2">
                              <h3 className="text-lg font-semibold text-gray-900">
                                {item.title}
                              </h3>
                              <span
                                className={`px-2 py-1 text-xs font-medium ${priorityConf.bgColor} ${priorityConf.textColor} rounded-full`}
                              >
                                {item.priority}
                              </span>
                            </div>
                            <p className="text-sm text-gray-600 mb-2">
                              {item.type}
                            </p>
                            <p className="text-gray-700">{item.description}</p>
                          </div>
                        </div>
                        <div className="flex items-center space-x-3">
                          <span
                            className={`inline-flex items-center px-3 py-1 text-sm font-medium rounded-full ${statusConf.bgColor} ${statusConf.textColor}`}
                          >
                            <StatusIcon
                              className={`w-4 h-4 mr-1 ${statusConf.iconColor}`}
                            />
                            {item.status}
                          </span>
                        </div>
                      </div>

                      {/* Details */}
                      <div className="grid grid-cols-2 gap-4 mb-4 text-sm">
                        <div>
                          <span className="text-gray-500">Assignee:</span>
                          <span className="ml-2 font-medium">
                            {item.assignee}
                          </span>
                        </div>
                        <div>
                          <span className="text-gray-500">Due Date:</span>
                          <span className="ml-2 font-medium">
                            {item.dueDate}
                          </span>
                        </div>
                        <div>
                          <span className="text-gray-500">Requester:</span>
                          <span className="ml-2 font-medium">
                            {item.requester}
                          </span>
                        </div>
                        <div>
                          <span className="text-gray-500">Category:</span>
                          <span className="ml-2 font-medium capitalize">
                            {item.category.replace("_", " ")}
                          </span>
                        </div>
                      </div>

                      {/* Additional Details */}
                      <div className="bg-gray-50 rounded-lg p-3 mb-4">
                        <div className="grid grid-cols-2 gap-4 text-sm">
                          {item.category === "user_approval" ? (
                            // Special display for user approval tasks
                            <>
                              <div>
                                <span className="text-gray-500">
                                  User Name:
                                </span>
                                <span className="ml-2 font-medium">
                                  {item.details.userName}
                                </span>
                              </div>
                              <div>
                                <span className="text-gray-500">
                                  User Email:
                                </span>
                                <span className="ml-2 font-medium">
                                  {item.details.userEmail}
                                </span>
                              </div>
                              <div>
                                <span className="text-gray-500">New Role:</span>
                                <span className="ml-2 font-medium">
                                  {item.details.newRole}
                                </span>
                              </div>
                              <div>
                                <span className="text-gray-500">
                                  Organization:
                                </span>
                                <span className="ml-2 font-medium">
                                  {item.details.newOrganization}
                                </span>
                              </div>
                            </>
                          ) : item.category === "auditor_assignment" ? (
                            // Special display for auditor assignment tasks
                            <>
                              <div>
                                <span className="text-gray-500">
                                  Auditor Name:
                                </span>
                                <span className="ml-2 font-medium">
                                  {item.details.auditorName}
                                </span>
                              </div>
                              <div>
                                <span className="text-gray-500">
                                  Auditor Email:
                                </span>
                                <span className="ml-2 font-medium">
                                  {item.details.auditorEmail}
                                </span>
                              </div>
                              <div>
                                <span className="text-gray-500">Project:</span>
                                <span className="ml-2 font-medium">
                                  {item.details.projectName}
                                </span>
                              </div>
                              <div>
                                <span className="text-gray-500">
                                  Framework:
                                </span>
                                <span className="ml-2 font-medium">
                                  {item.details.projectFramework}
                                </span>
                              </div>
                              <div>
                                <span className="text-gray-500">
                                  Organization:
                                </span>
                                <span className="ml-2 font-medium">
                                  {item.details.auditorOrganization}
                                </span>
                              </div>
                              <div>
                                <span className="text-gray-500">
                                  Department:
                                </span>
                                <span className="ml-2 font-medium">
                                  {item.details.department}
                                </span>
                              </div>
                            </>
                          ) : item.category === "risk_approval" ? (
                            // Special display for risk approval tasks
                            <>
                              <div>
                                <span className="text-gray-500">
                                  Risk Title:
                                </span>
                                <span className="ml-2 font-medium">
                                  {item.details.riskTitle}
                                </span>
                              </div>
                              <div>
                                <span className="text-gray-500">
                                  Risk Category:
                                </span>
                                <span className="ml-2 font-medium">
                                  {item.details.riskCategory}
                                </span>
                              </div>
                              <div>
                                <span className="text-gray-500">
                                  Risk Rating:
                                </span>
                                <span className="ml-2 font-medium">
                                  {item.details.riskRating}
                                </span>
                              </div>
                              <div>
                                <span className="text-gray-500">Impact:</span>
                                <span className="ml-2 font-medium">
                                  {item.details.impact}
                                </span>
                              </div>
                              <div>
                                <span className="text-gray-500">
                                  Likelihood:
                                </span>
                                <span className="ml-2 font-medium">
                                  {item.details.likelihood}
                                </span>
                              </div>
                              <div>
                                <span className="text-gray-500">Project:</span>
                                <span className="ml-2 font-medium">
                                  {item.details.projectName}
                                </span>
                              </div>
                              <div>
                                <span className="text-gray-500">
                                  Department:
                                </span>
                                <span className="ml-2 font-medium">
                                  {item.details.department}
                                </span>
                              </div>
                            </>
                          ) : (
                            // Default display for other tasks
                            Object.entries(item.details).map(([key, value]) => (
                              <div key={key}>
                                <span className="text-gray-500 capitalize">
                                  {key.replace(/([A-Z])/g, " $1")}:
                                </span>
                                <span className="ml-2 font-medium">
                                  {value}
                                </span>
                              </div>
                            ))
                          )}
                        </div>
                      </div>

                      {/* Actions */}
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-3">
                          {item.category === "auditor_assignment" ? (
                            // Show Approve/Reject buttons for auditor assignment tasks
                            <>
                              <button
                                onClick={() => handleAction(item.id, "Approve")}
                                className="px-4 py-2 text-sm font-medium rounded-full transition-all duration-200 transform hover:scale-105 active:scale-95 cursor-pointer bg-white text-green-500 shadow hover:bg-green-500 hover:text-white font-semibold"
                              >
                                Approve
                              </button>
                              <button
                                onClick={() => handleAction(item.id, "Reject")}
                                className="px-4 py-2 text-sm font-medium rounded-full transition-all duration-200 transform hover:scale-105 active:scale-95 cursor-pointer bg-white text-red-500 shadow hover:bg-red-500 hover:text-white font-semibold"
                              >
                                Reject
                              </button>
                            </>
                          ) : item.category === "risk_approval" ? (
                            // Show Approve/Reject buttons for risk approval tasks
                            <>
                              <button
                                onClick={() => handleAction(item.id, "Approve")}
                                className="px-4 py-2 text-sm font-medium rounded-full transition-all duration-200 transform hover:scale-105 active:scale-95 cursor-pointer bg-white text-green-500 shadow hover:bg-green-500 hover:text-white font-semibold"
                              >
                                Approve
                              </button>
                              <button
                                onClick={() => handleAction(item.id, "Reject")}
                                className="px-4 py-2 text-sm font-medium rounded-full transition-all duration-200 transform hover:scale-105 active:scale-95 cursor-pointer bg-white text-red-500 shadow hover:bg-red-500 hover:text-white font-semibold"
                              >
                                Reject
                              </button>
                            </>
                          ) : item.category === "auditor_assignment_legacy" ? (
                            // Legacy auditor assignment dropdown (for existing tasks)
                            <div className="relative">
                              <select
                                onChange={(e) =>
                                  handleAuditorAssign(item.id, e.target.value)
                                }
                                className="appearance-none bg-white text-teal-500 px-4 py-2 pr-8 rounded-full shadow hover:bg-teal-500 hover:text-white transition-all duration-200 transform hover:scale-105 active:scale-95 cursor-pointer font-semibold border border-teal-200"
                              >
                                <option value="">Assign Auditor</option>
                                {auditors.map((auditor) => (
                                  <option key={auditor.id} value={auditor.id}>
                                    {auditor.name} - {auditor.specialization}
                                  </option>
                                ))}
                              </select>
                              <FaChevronDown className="absolute right-2 top-3 w-3 h-3 text-white pointer-events-none" />
                            </div>
                          ) : (
                            item.actions.map((action, index) => (
                              <button
                                key={index}
                                onClick={() => handleAction(item.id, action)}
                                className={`px-4 py-2 text-sm font-medium rounded-full transition-all duration-200 transform hover:scale-105 active:scale-95 cursor-pointer font-semibold ${
                                  action === "Approve" || action === "Approved"
                                    ? "bg-white text-green-500 shadow hover:bg-green-500 hover:text-white"
                                    : action === "Reject"
                                    ? "bg-white text-red-500 shadow hover:bg-red-500 hover:text-white"
                                    : "bg-white text-gray-500 shadow hover:bg-gray-500 hover:text-white border border-gray-300"
                                }`}
                              >
                                {action}
                              </button>
                            ))
                          )}
                        </div>
                        <div className="flex items-center space-x-2">
                          <button className="p-2 text-gray-400 hover:text-teal-600 transition-all duration-200 transform hover:scale-110 active:scale-95 rounded-full hover:bg-teal-50">
                            <FaEye className="w-4 h-4" />
                          </button>
                          <button className="p-2 text-gray-400 hover:text-yellow-600 transition-all duration-200 transform hover:scale-110 active:scale-95 rounded-full hover:bg-yellow-50">
                            <FaEdit className="w-4 h-4" />
                          </button>
                          <button className="p-2 text-gray-400 hover:text-red-600 transition-all duration-200 transform hover:scale-110 active:scale-95 rounded-full hover:bg-red-50">
                            <FaTrash className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Right Sidebar - Progress Overview */}
          <div className="col-span-4 space-y-6">
            <div className="bg-white rounded-xl border border-gray-200 shadow-lg p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-6">
                Progress Overview
              </h3>

              {/* Circular Progress Chart */}
              <div className="text-center mb-6">
                <div className="relative inline-flex items-center justify-center w-40 h-40 mx-auto">
                  <svg
                    className="w-40 h-40 transform -rotate-90"
                    viewBox="0 0 120 120"
                  >
                    {/* Background circle */}
                    <circle
                      cx="60"
                      cy="60"
                      r="45"
                      fill="none"
                      stroke="#e5e7eb"
                      strokeWidth="8"
                    />

                    {/* Approved segment (Green) */}
                    <circle
                      cx="60"
                      cy="60"
                      r="45"
                      fill="none"
                      stroke="#10b981"
                      strokeWidth="8"
                      strokeLinecap="round"
                      strokeDasharray={`${approvedPercentage * 2.83} ${283}`}
                      strokeDashoffset="0"
                      className="transition-all duration-1000 ease-out"
                    />

                    {/* Pending segment (Yellow) */}
                    <circle
                      cx="60"
                      cy="60"
                      r="45"
                      fill="none"
                      stroke="#f59e0b"
                      strokeWidth="8"
                      strokeLinecap="round"
                      strokeDasharray={`${pendingPercentage * 2.83} ${283}`}
                      strokeDashoffset={`-${approvedPercentage * 2.83}`}
                      className="transition-all duration-1000 ease-out"
                    />

                    {/* Rejected segment (Red) */}
                    <circle
                      cx="60"
                      cy="60"
                      r="45"
                      fill="none"
                      stroke="#ef4444"
                      strokeWidth="8"
                      strokeLinecap="round"
                      strokeDasharray={`${rejectedPercentage * 2.83} ${283}`}
                      strokeDashoffset={`-${
                        (approvedPercentage + pendingPercentage) * 2.83
                      }`}
                      className="transition-all duration-1000 ease-out"
                    />
                  </svg>

                  <div className="absolute inset-0 flex flex-col items-center justify-center">
                    <span className="text-2xl font-bold text-gray-800">
                      {approvedPercentage}%
                    </span>
                    <span className="text-xs text-gray-500">Completed</span>
                  </div>
                </div>
              </div>

              {/* Statistics */}
              <div className="space-y-4">
                <div className="flex items-center justify-between p-3 bg-green-50 rounded-lg">
                  <div className="flex items-center space-x-3">
                    <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                    <span className="text-sm font-medium text-gray-700">
                      Approved
                    </span>
                  </div>
                  <span className="text-lg font-bold text-green-600">
                    {progressData.approved}
                  </span>
                </div>

                <div className="flex items-center justify-between p-3 bg-yellow-50 rounded-lg">
                  <div className="flex items-center space-x-3">
                    <div className="w-3 h-3 bg-yellow-500 rounded-full"></div>
                    <span className="text-sm font-medium text-gray-700">
                      Pending
                    </span>
                  </div>
                  <span className="text-lg font-bold text-yellow-600">
                    {progressData.pending}
                  </span>
                </div>

                <div className="flex items-center justify-between p-3 bg-red-50 rounded-lg">
                  <div className="flex items-center space-x-3">
                    <div className="w-3 h-3 bg-red-500 rounded-full"></div>
                    <span className="text-sm font-medium text-gray-700">
                      Rejected
                    </span>
                  </div>
                  <span className="text-lg font-bold text-red-600">
                    {progressData.rejected}
                  </span>
                </div>

                <div className="border-t pt-4">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium text-gray-700">
                      Total Tasks
                    </span>
                    <span className="text-xl font-bold text-gray-900">
                      {progressData.total}
                    </span>
                  </div>
                </div>
              </div>
            </div>

            {/* 3-Color Scheme Explanation */}
            <div className="bg-gradient-to-br from-green-50 to-teal-50 rounded-xl border border-green-200 shadow-sm p-6">
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-lg font-semibold text-teal-800">
                  STATUS CONNECTION
                </h3>
                <div className="w-6 h-6 bg-teal-100 rounded-full flex items-center justify-center">
                  <span className="text-xs font-bold text-teal-600">i</span>
                </div>
              </div>

              <div className="space-y-4">
                {/* Pending Status */}
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <div className="w-3 h-3 bg-yellow-500 rounded-full"></div>
                    <span className="text-sm font-medium text-teal-800">
                      Pending Tasks
                    </span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <span className="text-sm text-teal-700">→</span>
                    <span className="text-sm font-medium text-teal-800">
                      Awaiting Review
                    </span>
                  </div>
                </div>

                {/* Approved Status */}
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                    <span className="text-sm font-medium text-teal-800">
                      Approved Tasks
                    </span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <span className="text-sm text-teal-700">→</span>
                    <span className="text-sm font-medium text-teal-800">
                      Completed
                    </span>
                  </div>
                </div>

                {/* Rejected Status */}
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <div className="w-3 h-3 bg-red-500 rounded-full"></div>
                    <span className="text-sm font-medium text-teal-800">
                      Rejected Tasks
                    </span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <span className="text-sm text-teal-700">→</span>
                    <span className="text-sm font-medium text-teal-800">
                      Action Required
                    </span>
                  </div>
                </div>
              </div>

              {/* System Actions Explanation */}
              <div className="mt-6 pt-4 border-t border-green-200">
                <h4 className="text-sm font-semibold text-teal-800 mb-3">
                  System Actions
                </h4>
                <div className="space-y-2 text-xs text-teal-700">
                  <div className="flex items-start space-x-2">
                    <span className="text-green-600 font-bold">✓</span>
                    <span>
                      Approved: Updates related entities & logs audit trail
                    </span>
                  </div>
                  <div className="flex items-start space-x-2">
                    <span className="text-red-600 font-bold">✗</span>
                    <span>Rejected: Reverts changes & removes assignments</span>
                  </div>
                  <div className="flex items-start space-x-2">
                    <span className="text-yellow-600 font-bold">⏳</span>
                    <span>
                      Pending: Maintains current state until action taken
                    </span>
                  </div>
                </div>
              </div>
            </div>

            {/* Priority Level System */}
            <div className="bg-gradient-to-br from-red-50 to-orange-50 rounded-xl border border-red-200 shadow-sm p-6">
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-lg font-semibold text-red-800">
                  PRIORITY LEVELS
                </h3>
                <div className="w-6 h-6 bg-red-100 rounded-full flex items-center justify-center">
                  <span className="text-xs font-bold text-red-600">!</span>
                </div>
              </div>

              <div className="space-y-4">
                {/* High Priority */}
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <div className="w-3 h-3 bg-red-500 rounded-full"></div>
                    <span className="text-sm font-medium text-red-800">
                      High Priority
                    </span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <span className="text-sm text-red-700">→</span>
                    <span className="text-sm font-medium text-red-800">
                      Urgent Action
                    </span>
                  </div>
                </div>

                {/* Medium Priority */}
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <div className="w-3 h-3 bg-yellow-500 rounded-full"></div>
                    <span className="text-sm font-medium text-red-800">
                      Medium Priority
                    </span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <span className="text-sm text-red-700">→</span>
                    <span className="text-sm font-medium text-red-800">
                      Standard Review
                    </span>
                  </div>
                </div>

                {/* Low Priority */}
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                    <span className="text-sm font-medium text-red-800">
                      Low Priority
                    </span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <span className="text-sm text-red-700">→</span>
                    <span className="text-sm font-medium text-red-800">
                      Routine Task
                    </span>
                  </div>
                </div>
              </div>

              {/* Priority Guidelines */}
              <div className="mt-6 pt-4 border-t border-red-200">
                <h4 className="text-sm font-semibold text-red-800 mb-3">
                  Priority Guidelines
                </h4>
                <div className="space-y-2 text-xs text-red-700">
                  <div className="flex items-start space-x-2">
                    <span className="text-red-600 font-bold">🔴</span>
                    <span>
                      High: Critical security, compliance violations, urgent
                      approvals
                    </span>
                  </div>
                  <div className="flex items-start space-x-2">
                    <span className="text-yellow-600 font-bold">🟡</span>
                    <span>
                      Medium: Standard reviews, routine assessments, normal
                      workflows
                    </span>
                  </div>
                  <div className="flex items-start space-x-2">
                    <span className="text-green-600 font-bold">🟢</span>
                    <span>
                      Low: Documentation updates, minor changes, background
                      tasks
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ComplianceToDoTracker;
