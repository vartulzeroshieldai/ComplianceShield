import React from "react";
import { FaDownload, FaFileAlt, FaCalendarAlt } from "react-icons/fa";

export default function Report({ project }) {
  const handleDownloadReport = () => {
    // This would typically make an API call to generate and download the report
    console.log("Downloading report for project:", project?.name || "Current Project");
    
    // Mock download functionality
    const element = document.createElement("a");
    const file = new Blob(["Project Report Content"], { type: "application/pdf" });
    element.href = URL.createObjectURL(file);
    element.download = `${project?.name || "Project"}_Report_${new Date().toISOString().split('T')[0]}.pdf`;
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
  };

  return (
    <div className="bg-white rounded-lg border border-gray-200 p-8">
      {/* Report Header */}
      <div className="text-center  max-w-md mx-auto">
        <div className="w-16 h-16 bg-teal-100 rounded-full flex items-center justify-center mx-auto mb-6">
          <FaFileAlt className="text-teal-600 text-2xl" />
        </div>
        
        <h2 className="text-2xl font-semibold text-gray-800 mb-3">Project Report</h2>
        
        <p className="text-gray-600 mb-8 leading-relaxed">
          Generate and download a comprehensive report containing all project details, controls implementation status, and compliance metrics.
        </p>
        
        {/* Download Button */}
        <div className="mb-6 flex justify-center">
        <button
          onClick={handleDownloadReport}
          className="flex items-center space-x-2 px-5 py-2 rounded-full bg-white text-teal-400 font-semibold shadow hover:bg-teal-400 hover:text-white focus:outline-none transition-colors cursor-pointer"
        >
          <FaDownload className="text-lg" />
          <span className="font-medium">Download Report</span>
        </button>
        </div>
        {/* Additional Info */}
        <div className="mt-6 flex items-center justify-center text-sm text-gray-500">
          <FaCalendarAlt className="mr-2" />
          <span>Last updated: {new Date().toLocaleDateString()}</span>
        </div>
      </div>
    </div>
  );
}
