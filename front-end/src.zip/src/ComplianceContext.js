import { createContext } from "react";

// Create context
export const ComplianceContext = createContext();
